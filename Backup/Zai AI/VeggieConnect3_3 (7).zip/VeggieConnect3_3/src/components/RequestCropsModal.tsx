import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  Plus,
  CheckCircle2,
  X,
  Send,
  PackageCheck,
  AlertTriangle,
  FileText,
} from 'lucide-react';
import { ProduceItem, Order, OrderItem, UserProfile } from '../types';
import { buyerUnitPrice, farmerUnitPrice } from '../utils/pricing';
import { MIN_ORDER_KG, MIN_PRODUCT_KG } from './ProduceCard';

interface RequestCropsModalProps {
  isOpen: boolean;
  /** When set, the modal opens pre-filled with THIS market crop (product-specific request). */
  presetProduct: ProduceItem | null;
  /** Optional quantity carried over from the produce detail modal stepper. */
  preferredQty?: number;
  /** Live Market menu products — "Choose a Vegetable" only lists these. */
  produceList: ProduceItem[];
  currentUser: UserProfile | null;
  onClose: () => void;
  onOrderPlaced: (order: Order) => void;
}

/**
 * Vegetable Purchase Request modal (Buyer → Admin).
 *
 * Reached from the CART menu ("Request Crops" button) for a generic
 * multi-product request, or from any Market product ("Request" tap on a
 * card / in the detail modal) for a product-specific request.
 *
 * - "Choose a Vegetable" lists ONLY crops currently available on the Market
 *   menu (in-stock shelf products) — buyers can never request a crop the
 *   Market doesn't actually sell.
 * - Requested quantities are capped at each crop's shelf stock.
 * - Minimum order: 60 kg in TOTAL across every product in the request, and
 *   each product must be at least 20 kg on its own.
 */
export const RequestCropsModal: React.FC<RequestCropsModalProps> = ({
  isOpen,
  presetProduct,
  preferredQty,
  produceList,
  currentUser,
  onClose,
  onOrderPlaced,
}) => {
  // ── Order rules (mirrors the Cart menu rules) ────────────────────────
  // 1) TOTAL minimum: every product's kg is summed; the total must reach
  //    at least 60 kg (single or multi-product requests alike).
  // 2) PER-PRODUCT minimum: each product must be at least 20 kg on its own.

  const [requestVegetables, setRequestVegetables] = useState<Array<{ name: string; quantity: number; unit: string; estimatedPrice: number; farmgateUnitPrice?: number }>>([]);
  const [selectedPresetCrop, setSelectedPresetCrop] = useState('');
  const [customCropQty, setCustomCropQty] = useState(MIN_PRODUCT_KG);
  const [buyerReqName, setBuyerReqName] = useState(currentUser?.name || '');
  const [buyerReqPhone, setBuyerReqPhone] = useState(currentUser?.phone || '');
  const [buyerReqSlot, setBuyerReqSlot] = useState('Today at 3:00 PM (Store Depot Pickup)');
  const [isSubmittingRequest, setIsSubmittingRequest] = useState(false);
  const [requestSuccessMsg, setRequestSuccessMsg] = useState<string | null>(null);

  // Product-specific request context: when the buyer taps "Request" on a market
  // card (or inside the produce detail modal), the request modal opens pre-filled
  // with THAT crop. availableStock caps the requested quantity.
  const [requestProductInfo, setRequestProductInfo] = useState<{ name: string; availableStock: number; unit: string; farmgateUnitPrice?: number } | null>(null);

  // ── Stock-aware request validation ─────────────────────────────────────
  // Any requested item that matches a crop currently listed on the Market is
  // capped at that crop's available shelf stock, so a buyer can never request
  // more than the shelf can actually supply (overselling guard).
  const [stockWarning, setStockWarning] = useState<string | null>(null);

  // (Re)initialize the whole form every time the modal opens — a generic
  // "Request Crops" tap from the Cart starts with a CLEAN slate (no items,
  // no stale warnings), while a product-specific tap is pre-filled with
  // THAT crop, capped at its available shelf stock.
  useEffect(() => {
    if (!isOpen) return;
    setRequestSuccessMsg(null);
    setStockWarning(null);
    setIsSubmittingRequest(false);
    setBuyerReqName(currentUser?.name || '');
    setBuyerReqPhone(currentUser?.phone || '');
    setSelectedPresetCrop('');
    setCustomCropQty(MIN_PRODUCT_KG);

    if (presetProduct) {
      const stock =
        typeof presetProduct.stockQuantity === 'number'
          ? presetProduct.stockQuantity
          : parseInt(String(presetProduct.stockQuantity), 10) || 0;
      const price = buyerUnitPrice(presetProduct);
      const unit = presetProduct.unit || 'kg';
      // Product-specific requests start at the 20 kg per-product minimum
      // (or the carried-over stepper quantity, whichever is larger), always
      // capped at the shelf stock.
      const initialQty = Math.min(
        Math.max(MIN_PRODUCT_KG, Math.floor(preferredQty || MIN_PRODUCT_KG)),
        Math.max(MIN_PRODUCT_KG, stock)
      );
      setRequestVegetables([
        {
          name: presetProduct.name,
          quantity: initialQty,
          unit,
          estimatedPrice: price,
          farmgateUnitPrice: farmerUnitPrice(presetProduct),
        },
      ]);
      setRequestProductInfo({
        name: presetProduct.name,
        availableStock: stock,
        unit,
        farmgateUnitPrice: farmerUnitPrice(presetProduct),
      });
    } else {
      setRequestVegetables([]);
      setRequestProductInfo(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, presetProduct, preferredQty]);

  const getAvailableStockFor = useCallback(
    (name: string): { stock: number; unit: string } | null => {
      const q = (name || '').trim().toLowerCase();
      if (!q) return null;
      const match =
        produceList.find((p) => (p.name || '').trim().toLowerCase() === q) ||
        produceList.find(
          (p) =>
            ((p.name || '').toLowerCase().includes(q) || q.includes((p.name || '').toLowerCase())) &&
            (p.name || '').length > 0
        );
      if (!match) return null;
      const stock =
        typeof match.stockQuantity === 'number' ? match.stockQuantity : parseInt(String(match.stockQuantity), 10) || 0;
      return { stock, unit: match.unit || 'kg' };
    },
    [produceList]
  );

  // "Choose a Vegetable" options come straight from the LIVE MARKET MENU —
  // a buyer can only request crops that are actually available on the Market
  // right now (in-stock shelf products). Sold-out crops are excluded because
  // they cannot be bought, and the list is priced with the live buyer market
  // price (farmer asking price + Admin commission).
  const marketVegetableOptions = useMemo(() => {
    if (!Array.isArray(produceList)) return [];
    return produceList
      .filter((p) => {
        if (!p) return false;
        const stock =
          typeof p.stockQuantity === 'number' ? p.stockQuantity : parseInt(String(p.stockQuantity), 10) || 0;
        return stock > 0;
      })
      .map((p) => ({
        produce: p,
        name: p.name || 'Fresh Produce',
        price: buyerUnitPrice(p),
        farmgatePrice: farmerUnitPrice(p),
        stock:
          typeof p.stockQuantity === 'number' ? p.stockQuantity : parseInt(String(p.stockQuantity), 10) || 0,
        unit: p.unit || 'kg',
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [produceList]);

  // Total kg across every requested product — the 60 kg minimum applies to
  // this SUM, so buying more than 1 product still works as long as the
  // combined kg reaches the threshold. Each product must additionally be
  // at least 20 kg on its own.
  const totalRequestedKg = requestVegetables.reduce((s, v) => s + (v.quantity || 0), 0);
  const meetsTotalMin = totalRequestedKg >= MIN_ORDER_KG;
  const productsBelowMin = requestVegetables.filter((v) => (v.quantity || 0) < MIN_PRODUCT_KG);
  const meetsPerProductMin = productsBelowMin.length === 0;
  const meetsMinOrder = meetsTotalMin && meetsPerProductMin;

  const closeAndReset = () => {
    onClose();
    setRequestSuccessMsg(null);
    setStockWarning(null);
  };

  // Handle adding vegetable to the custom request — the crop always comes
  // from the "Choose a Vegetable" dropdown, which lists ONLY Market menu
  // products. Price and stock therefore always follow the live market data.
  const handleAddVegetableToRequest = () => {
    const nameToAdd = selectedPresetCrop.trim();
    if (!nameToAdd) return;

    // Live market data for this crop (price + shelf stock)
    const marketOpt = marketVegetableOptions.find(
      (o) => o.name.toLowerCase() === nameToAdd.toLowerCase()
    );
    const estPrice = marketOpt?.price || 60;
    const farmgatePrice = marketOpt?.farmgatePrice;

    setStockWarning(null);

    // Shelf-stock guard: the crop is a Market product, so its available
    // shelf stock caps the requested quantity (overselling guard).
    const stockInfo = getAvailableStockFor(nameToAdd);
    if (stockInfo && stockInfo.stock <= 0) {
      setStockWarning(`${nameToAdd} is currently sold out — no shelf stock available to request.`);
      return;
    }

    const existing = requestVegetables.find((i) => i.name.toLowerCase() === nameToAdd.toLowerCase());
    let cappedNow = false;
    let nextList: Array<{ name: string; quantity: number; unit: string; estimatedPrice: number; farmgateUnitPrice?: number }>;
    if (existing) {
      nextList = requestVegetables.map((i) => {
        if (i.name.toLowerCase() !== nameToAdd.toLowerCase()) return i;
        let nextQty = i.quantity + customCropQty;
        // Cap product-specific requests at the farmer's available stock
        if (requestProductInfo && i.name.toLowerCase() === requestProductInfo.name.toLowerCase()) {
          nextQty = Math.min(nextQty, requestProductInfo.availableStock);
        }
        if (stockInfo && nextQty > stockInfo.stock) {
          nextQty = stockInfo.stock;
          cappedNow = true;
        }
        return { ...i, quantity: nextQty };
      });
    } else {
      let addQty = customCropQty;
      if (stockInfo && addQty > stockInfo.stock) {
        addQty = stockInfo.stock;
        cappedNow = true;
      }
      nextList = [
        ...requestVegetables,
        {
          name: nameToAdd,
          quantity: addQty,
          unit: stockInfo?.unit || 'kg',
          estimatedPrice: estPrice,
          farmgateUnitPrice: farmgatePrice,
        },
      ];
    }
    setRequestVegetables(nextList);

    if (cappedNow && stockInfo) {
      setStockWarning(
        `Only ${stockInfo.stock} ${stockInfo.unit} of ${nameToAdd} available on the shelf — your quantity was capped.`
      );
    }

    setSelectedPresetCrop('');
    setCustomCropQty(MIN_PRODUCT_KG);
  };

  const handleRemoveVegetableFromRequest = (index: number) => {
    setRequestVegetables((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleUpdateReqQty = (index: number, newQty: number) => {
    if (newQty < MIN_PRODUCT_KG) {
      // 20 kg per-product minimum — the minus stepper never goes below it;
      // buyers remove a product with its ✕ button instead.
      setStockWarning(`Each product must be at least ${MIN_PRODUCT_KG} kg. Use the ✕ button to remove ${requestVegetables[index]?.name || 'this product'} from the request.`);
      return;
    }
    setStockWarning(null);
    setRequestVegetables((prev) =>
      prev.map((item, idx) => {
        if (idx !== index) return item;
        let clamped = newQty;
        // Product-specific requests can never exceed the farmer's available stock
        if (requestProductInfo && item.name.toLowerCase() === requestProductInfo.name.toLowerCase()) {
          clamped = Math.min(clamped, requestProductInfo.availableStock);
        }
        // Market shelf guard: listed crops cap at available stock
        const stockInfo = getAvailableStockFor(item.name);
        if (stockInfo) {
          clamped = Math.min(clamped, stockInfo.stock);
        }
        return { ...item, quantity: clamped };
      })
    );
  };

  // Submit Buyer Purchase Request to Admin
  const handleSubmitBuyerRequest = () => {
    if (requestVegetables.length === 0) return;

    // ── Per-product gate: EACH product must be at least 20 kg ─────────
    if (!meetsPerProductMin) {
      setStockWarning(
        `Each product must be at least ${MIN_PRODUCT_KG} kg — ${productsBelowMin
          .map((v) => `${v.name} (${v.quantity} kg)`)
          .join(', ')} ${productsBelowMin.length === 1 ? 'is' : 'are'} below the minimum. Raise the quantity or remove the product.`
      );
      return;
    }

    // ── Total gate: 60 kg across ALL products ──────────────────────
    // A buyer must purchase at least 60 kg in TOTAL. Buying more than one
    // product is fine — every product's kg is added together and the sum
    // must be greater than (or equal to) 60 kg.
    if (totalRequestedKg < MIN_ORDER_KG) {
      setStockWarning(
        `Minimum order is ${MIN_ORDER_KG} kg — your request currently totals ${totalRequestedKg} kg. Add ${(MIN_ORDER_KG - totalRequestedKg).toFixed(0)} more kg (either the same product or another one) to reach the minimum.`
      );
      return;
    }

    // ── Final stock gate (safety net) ─────────────────────────────────
    // Every item matching a listed market crop must be within its
    // available shelf stock before the request can be submitted.
    const problems: string[] = [];
    for (const v of requestVegetables) {
      const info = getAvailableStockFor(v.name);
      if (info && v.quantity > info.stock) {
        problems.push(`${v.name}: requested ${v.quantity}${v.unit}, only ${info.stock}${info.unit} available`);
      }
    }
    if (problems.length > 0) {
      setStockWarning(`Not enough shelf stock — ${problems.join(' • ')}. Please adjust the quantities.`);
      return;
    }
    setStockWarning(null);

    const trimmedName = (buyerReqName || currentUser?.name || 'Valued Buyer').trim();
    const trimmedPhone = (buyerReqPhone || currentUser?.phone || '0917 000 0000').trim();
    const trimmedSlot = buyerReqSlot.trim() || 'Store Depot Pickup';

    setIsSubmittingRequest(true);

    const isProductRequest = Boolean(requestProductInfo);
    const orderItems: OrderItem[] = requestVegetables.map((v, i) => {
      // Every request lot is a Market product — record the farmer's asking
      // price so the Admin commission (market price − farmgate price) is
      // tracked per kg.
      return {
        produceId: `req-prod-${Date.now()}-${i}`,
        produceName: v.name,
        imageUrl: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80',
        unitPrice: v.estimatedPrice,
        pricePerUnit: v.estimatedPrice,
        farmgateUnitPrice: v.farmgateUnitPrice,
        unit: v.unit,
        quantity: v.quantity,
        farmName: 'VeggieConnect Central Market',
        farmerId: 'admin-main',
      };
    });

    // Commission split for product lots with a known farmgate price.
    const totalAmt = requestVegetables.reduce((sum, v) => sum + v.quantity * v.estimatedPrice, 0);
    const farmgateCostTotal = Math.round(orderItems.reduce((s, it) => s + (it.farmgateUnitPrice || 0) * (it.quantity || 0), 0) * 100) / 100;
    const adminCommissionTotal = farmgateCostTotal > 0 ? Math.round((totalAmt - farmgateCostTotal) * 100) / 100 : undefined;

    const newRequestOrder: Order = {
      id: `VC-REQ-${Math.floor(1000 + Math.random() * 9000)}`,
      buyerId: currentUser?.id || 'buyer-custom',
      buyerName: trimmedName,
      buyerPhone: trimmedPhone,
      sellerStoreName: 'VeggieConnect Central Market',
      brokerHubName: 'VeggieConnect Central Market',
      deliveryType: 'farm_pickup',
      pickupSlot: trimmedSlot,
      items: orderItems,
      subtotal: totalAmt,
      deliveryFee: 0,
      totalAmount: totalAmt,
      farmgateCostTotal: farmgateCostTotal > 0 ? farmgateCostTotal : undefined,
      adminCommissionTotal,
      status: 'pending', // Buyer request submitted, awaits Admin processing
      createdAt: new Date().toISOString(),
      farmerId: 'admin-main',
      farmName: 'VeggieConnect Central Market',
      paymentMethod: 'Over-the-Counter Cash at Depot',
      notes: isProductRequest
        ? `Product Request (Buyer-Led Workflow): Buyer requested "${requestProductInfo?.name}" from the Market catalog (${orderItems.length} vegetable lot(s)). Admin to source from the farmer's current harvest and fulfill.`
        : `Buyer Purchase Request (Buyer-Led Workflow): Details ${orderItems.length} specific vegetable lot(s) requested for Admin inventory verification and fulfillment.`,
    };

    setTimeout(() => {
      setIsSubmittingRequest(false);
      setRequestSuccessMsg(`Request #${newRequestOrder.id} submitted to Admin!`);
      if (onOrderPlaced) {
        onOrderPlaced(newRequestOrder);
      }
      setTimeout(() => {
        closeAndReset();
      }, 1400);
    }, 500);
  };

  if (!isOpen) return null;

  return (
    /* `absolute` (not `fixed`) anchors the overlay to the phone shell so the
       request form always fits INSIDE the app frame — it can never spill
       over the app's size; long content scrolls within the sheet itself. */
    <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-md w-full max-h-full overflow-y-auto shadow-2xl border border-emerald-200 p-5 space-y-4 text-emerald-950">
        {/* Modal Header */}
        <div className="flex items-start justify-between border-b border-neutral-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <FileText className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-emerald-950">
                Vegetable Purchase Request
              </h3>
              <p className="text-[11px] text-emerald-700 font-semibold">
                Detail Vegetables &amp; Quantities to Admin
              </p>
            </div>
          </div>
          <button
            onClick={closeAndReset}
            className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Product-specific request banner: shows when the buyer tapped
            "Request" on a market crop. Quantity is capped at farmer stock. */}
        {requestProductInfo && (
          <div className="bg-emerald-600 text-white rounded-2xl p-3 flex items-center gap-2.5 shadow-xs">
            <div className="w-8 h-8 rounded-xl bg-white/15 flex items-center justify-center flex-shrink-0">
              <PackageCheck className="w-4 h-4 text-emerald-100" />
            </div>
            <div className="min-w-0">
              <h4 className="text-xs font-extrabold truncate">Requesting: {requestProductInfo.name}</h4>
              <p className="text-[10px] text-emerald-100 font-medium">
                {requestProductInfo.availableStock} {requestProductInfo.unit} available from today's farmer harvest — request quantity is capped at this amount.
              </p>
            </div>
          </div>
        )}

        {/* Add Vegetables Form */}
        <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-2xl p-3.5 space-y-3">
          <h4 className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5 text-emerald-600" />
            <span>Add Vegetable to Request</span>
          </h4>

          <div className="space-y-2">
            <div>
              <label className="text-[10px] font-bold text-emerald-900 block mb-1">
                Choose a Vegetable (available on the Market menu):
              </label>
              <select
                value={selectedPresetCrop}
                onChange={(e) => setSelectedPresetCrop(e.target.value)}
                className="w-full bg-white border border-emerald-200 rounded-xl px-3 py-2 text-xs text-neutral-900 focus:outline-none focus:border-emerald-600"
              >
                <option value="">-- Choose a Vegetable --</option>
                {marketVegetableOptions.map((v) => (
                  <option key={v.produce.id} value={v.name}>
                    {v.name} — ₱{v.price.toFixed(2)}/{v.unit} • {v.stock} {v.unit} available
                  </option>
                ))}
              </select>
              {marketVegetableOptions.length === 0 && (
                <p className="text-[10px] text-amber-700 font-semibold mt-1">
                  No products are currently available on the Market menu — check back soon.
                </p>
              )}
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-white border border-emerald-200 rounded-xl px-2 py-1">
                <button
                  type="button"
                  onClick={() => setCustomCropQty(Math.max(MIN_PRODUCT_KG, customCropQty - 1))}
                  disabled={customCropQty <= MIN_PRODUCT_KG}
                  className="w-6 h-6 rounded-lg bg-neutral-100 hover:bg-neutral-200 disabled:opacity-40 text-neutral-700 font-bold flex items-center justify-center cursor-pointer text-xs"
                  title={`Minimum ${MIN_PRODUCT_KG} kg per product`}
                >
                  -
                </button>
                <span className="font-bold text-xs text-neutral-900 px-1 font-mono">
                  {customCropQty} kg
                </span>
                <button
                  type="button"
                  onClick={() => setCustomCropQty(customCropQty + 1)}
                  className="w-6 h-6 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center justify-center cursor-pointer text-xs"
                >
                  +
                </button>
              </div>
              <p className="text-[10px] text-neutral-500 font-medium leading-tight">
                Min <span className="font-bold text-emerald-800">{MIN_PRODUCT_KG} kg</span> per product
                <br />
                Total min <span className="font-bold text-emerald-800">{MIN_ORDER_KG} kg</span>
              </p>
              <button
                type="button"
                onClick={handleAddVegetableToRequest}
                disabled={!selectedPresetCrop}
                className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-bold text-xs rounded-xl cursor-pointer shadow-xs"
              >
                Add
              </button>
            </div>
          </div>
        </div>

        {/* List of Requested Vegetables */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
            <span>Requested Items ({requestVegetables.length})</span>
            <span className="text-[11px] text-neutral-500 font-medium">Estimated Pricing</span>
          </div>

          {requestVegetables.length === 0 ? (
            <div className="p-4 text-center text-xs text-neutral-500 bg-neutral-50 rounded-2xl border border-neutral-200">
              No vegetables added yet. Choose a vegetable from the Market menu above!
            </div>
          ) : (
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {requestVegetables.map((item, idx) => (
                <div
                  key={idx}
                  className="bg-white border border-emerald-200/80 rounded-2xl p-2.5 flex items-center justify-between gap-2 shadow-2xs"
                >
                  <div className="min-w-0">
                    <h5 className="font-bold text-xs text-emerald-950 truncate">{item.name}</h5>
                    <p className="text-[10px] text-neutral-500">
                      ~₱{item.estimatedPrice}/{item.unit} • Est. Subtotal: ₱{(item.quantity * item.estimatedPrice).toFixed(2)}
                    </p>
                    {(() => {
                      const info = getAvailableStockFor(item.name);
                      if (!info) {
                        return <p className="text-[10px] text-neutral-400 italic">Custom request — Admin will source from farmers</p>;
                      }
                      const atCap = item.quantity >= info.stock;
                      return (
                        <p className={`text-[10px] font-bold ${atCap ? 'text-amber-600' : 'text-emerald-600'}`}>
                          {info.stock} {info.unit} available on shelf{atCap ? ' • at maximum' : ''}
                        </p>
                      );
                    })()}
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <div className="flex items-center gap-1 bg-emerald-50 border border-emerald-200 rounded-lg p-0.5">
                      <button
                        type="button"
                        onClick={() => handleUpdateReqQty(idx, item.quantity - 1)}
                        disabled={item.quantity <= MIN_PRODUCT_KG}
                        className="w-5 h-5 rounded bg-white text-emerald-900 font-bold flex items-center justify-center text-xs cursor-pointer shadow-2xs disabled:opacity-40"
                        title={`Minimum ${MIN_PRODUCT_KG} kg per product`}
                      >
                        -
                      </button>
                      <span className="text-xs font-extrabold text-emerald-950 px-1 font-mono">
                        {item.quantity} {item.unit}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleUpdateReqQty(idx, item.quantity + 1)}
                        disabled={(() => {
                          const info = getAvailableStockFor(item.name);
                          return info ? item.quantity >= info.stock : false;
                        })()}
                        className="w-5 h-5 rounded bg-emerald-600 text-white font-bold flex items-center justify-center text-xs cursor-pointer shadow-2xs disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        +
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleRemoveVegetableFromRequest(idx)}
                      className="p-1 text-neutral-400 hover:text-rose-600 rounded-md cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Stock validation warning (overselling guard) */}
        {stockWarning && (
          <div className="bg-amber-50 border border-amber-300 rounded-2xl p-2.5 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-[11px] font-bold text-amber-900 leading-relaxed">{stockWarning}</p>
          </div>
        )}

        {/* Minimum order progress: the request must total at least 60 kg
            across ALL products (sum of every item's kg), and each product
            must be at least 20 kg on its own. */}
        <div className={`rounded-2xl p-3 border space-y-2 ${meetsMinOrder ? 'bg-emerald-50 border-emerald-300' : 'bg-amber-50 border-amber-300'}`}>
          <div className="flex items-center justify-between text-[11px] font-bold">
            <span className={meetsMinOrder ? 'text-emerald-900' : 'text-amber-900'}>
              Minimum Order: {MIN_ORDER_KG} kg total • {MIN_PRODUCT_KG} kg per product
            </span>
            <span className={meetsMinOrder ? 'text-emerald-700' : 'text-amber-700'}>
              {meetsTotalMin ? '✓ Total reached' : `${Math.max(0, MIN_ORDER_KG - totalRequestedKg).toFixed(0)} kg to go`}
            </span>
          </div>
          <div className="h-2 w-full bg-white rounded-full overflow-hidden border border-neutral-200">
            <div
              className={`h-full rounded-full transition-all ${meetsTotalMin ? 'bg-emerald-600' : 'bg-amber-500'}`}
              style={{ width: `${Math.min(100, (totalRequestedKg / MIN_ORDER_KG) * 100)}%` }}
            />
          </div>
          <p className={`text-[10px] font-semibold ${meetsMinOrder ? 'text-emerald-700' : 'text-amber-700'}`}>
            {meetsMinOrder
              ? `✓ Total ${totalRequestedKg} kg — minimum order met (${requestVegetables.length} product${requestVegetables.length === 1 ? '' : 's'}, each ≥ ${MIN_PRODUCT_KG} kg).`
              : `Currently ${totalRequestedKg} kg across ${requestVegetables.length} product${requestVegetables.length === 1 ? '' : 's'} — all product kg are added together and the total must reach ${MIN_ORDER_KG} kg, with every product at ${MIN_PRODUCT_KG} kg or more.`}
          </p>
          {!meetsPerProductMin && (
            <p className="text-[10px] font-bold text-amber-800 bg-amber-100 border border-amber-300 rounded-xl px-2.5 py-1.5">
              ⚠ Below {MIN_PRODUCT_KG} kg: {productsBelowMin.map((v) => `${v.name} (${v.quantity} kg)`).join(', ')} — raise the quantity or remove the product.
            </p>
          )}
        </div>

        {/* Buyer Contact & Pickup Information */}
        <div className="space-y-2 text-xs pt-1 border-t border-neutral-100">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] font-bold text-neutral-700 block mb-0.5">Your Name:</label>
              <input
                type="text"
                value={buyerReqName}
                onChange={(e) => setBuyerReqName(e.target.value)}
                placeholder="Enter full name"
                className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-2.5 py-1.5 text-xs text-neutral-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold text-neutral-700 block mb-0.5">Phone Number:</label>
              <input
                type="text"
                value={buyerReqPhone}
                onChange={(e) => setBuyerReqPhone(e.target.value)}
                placeholder="0917 123 4567"
                className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-2.5 py-1.5 text-xs text-neutral-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-neutral-700 block mb-0.5">Pickup Time / Delivery Slot:</label>
            <input
              type="text"
              value={buyerReqSlot}
              onChange={(e) => setBuyerReqSlot(e.target.value)}
              placeholder="e.g. Today at 3:00 PM (Central Depot Pickup)"
              className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-2.5 py-1.5 text-xs text-neutral-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
            />
          </div>
        </div>

        {/* Total Summary */}
        <div className="bg-emerald-100/70 p-3 rounded-2xl flex items-center justify-between border border-emerald-300">
          <div>
            <span className="text-[10px] text-emerald-800 uppercase font-bold block">
              Estimated Total ({requestVegetables.reduce((s, v) => s + v.quantity, 0)} kg requested):
            </span>
            <span className="text-lg font-black text-emerald-950 font-mono">
              ₱{requestVegetables.reduce((sum, v) => sum + v.quantity * v.estimatedPrice, 0).toFixed(2)}
            </span>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-emerald-800 font-semibold block">Fulfillment:</span>
            <span className="text-xs font-bold text-emerald-950">VeggieConnect Depot</span>
          </div>
        </div>

        {requestSuccessMsg && (
          <div className="p-3 bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-200 flex-shrink-0" />
            <span>{requestSuccessMsg}</span>
          </div>
        )}

        {/* Submit Action Button */}
        <button
          type="button"
          id="btn-submit-vegetable-request"
          onClick={handleSubmitBuyerRequest}
          disabled={isSubmittingRequest || requestVegetables.length === 0 || !meetsMinOrder}
          className="w-full min-h-[46px] py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-extrabold text-xs shadow-md flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
        >
          {isSubmittingRequest ? (
            <span className="flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Submitting Request to Admin...
            </span>
          ) : requestVegetables.length > 0 && !meetsPerProductMin ? (
            <>
              <Send className="w-4 h-4" />
              <span>Each product needs {MIN_PRODUCT_KG} kg or more</span>
            </>
          ) : requestVegetables.length > 0 && !meetsTotalMin ? (
            <>
              <Send className="w-4 h-4" />
              <span>Need {(MIN_ORDER_KG - totalRequestedKg).toFixed(0)} more kg to submit</span>
            </>
          ) : (
            <>
              <Send className="w-4 h-4" />
              <span>Submit Purchase Request to Admin</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
