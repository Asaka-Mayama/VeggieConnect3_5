import { Order } from '../types';

/**
 * Date-grouping helpers shared by the Farmer Orders menu and the
 * Admin "All Ledger" transactions view.
 *
 * Every order is bucketed under a LOCAL calendar-day key (YYYY-MM-DD).
 * Orders whose createdAt is missing or unparseable (legacy/demo rows such as
 * "Just now") fall into the special 'unrecorded' bucket so they are never
 * silently dropped from the ledger.
 */

export const UNRECORDED_DATE_KEY = 'unrecorded';

const pad2 = (n: number) => String(n).padStart(2, '0');

/** Stable local calendar-day key (YYYY-MM-DD) for an order timestamp. */
export const getOrderDateKey = (createdAt?: string): string => {
  if (createdAt) {
    const d = new Date(createdAt);
    if (!isNaN(d.getTime())) {
      return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
    }
  }
  return UNRECORDED_DATE_KEY;
};

const todayKey = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
};

const yesterdayKey = (): string => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
};

/** Long label used on date section headers: "Friday, November 14, 2026". */
export const formatDateKeyLabel = (key: string): string => {
  if (key === UNRECORDED_DATE_KEY) return 'Unrecorded Date';
  const [y, m, d] = key.split('-').map(Number);
  if (!y || !m || !d) return key;
  const dt = new Date(y, m - 1, d);
  return dt.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
};

/** Compact label used on date chips: "Today", "Yesterday", "Nov 13, 2026". */
export const formatDateKeyShort = (key: string): string => {
  if (key === UNRECORDED_DATE_KEY) return 'No Date';
  if (key === todayKey()) return 'Today';
  if (key === yesterdayKey()) return 'Yesterday';
  const [y, m, d] = key.split('-').map(Number);
  if (!y || !m || !d) return key;
  const dt = new Date(y, m - 1, d);
  return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

/** Human date+time string for a single order, '' when unparseable. */
export const formatOrderDateTime = (createdAt?: string): string => {
  if (!createdAt) return '';
  const d = new Date(createdAt);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
};

/** Sort date keys newest-first, always pushing the 'unrecorded' bucket last. */
export const sortDateKeysDesc = (keys: string[]): string[] =>
  [...keys].sort((a, b) => {
    if (a === UNRECORDED_DATE_KEY) return 1;
    if (b === UNRECORDED_DATE_KEY) return -1;
    return b.localeCompare(a);
  });

/** Money-safe number for an order's transaction amount. */
export const orderAmount = (order: Order): number =>
  Number(order.totalAmount ?? order.subtotal) || 0;

/** Money-safe number for what the Admin PAYS the farmer (farm-gate cost). */
export const orderFarmgateCost = (order: Order): number => {
  const farmgate = Number(order.farmgateCostTotal);
  if (!isNaN(farmgate) && farmgate > 0) return farmgate;
  // Fallback: derive from item-level farm-gate unit prices.
  const fromItems = (order.items || []).reduce(
    (s, it) => s + (Number(it.farmgateUnitPrice) || 0) * (Number(it.quantity) || 0),
    0
  );
  if (fromItems > 0) return Math.round(fromItems * 100) / 100;
  return orderAmount(order);
};

/**
 * Admin "All Ledger" categorisation — mirrors the Buyer Requests filter rule:
 * a transaction belongs to the FARMER category when it is the admin buying
 * produce from a farmer (admin procurement); everything else is a BUYER sale.
 */
export const isFarmerProcurementOrder = (order: Order): boolean =>
  String(order.buyerId || '') === 'admin-main' ||
  String(order.id || '').startsWith('TX-ADM-') ||
  (order.buyerName || '').toLowerCase().includes('admin');
