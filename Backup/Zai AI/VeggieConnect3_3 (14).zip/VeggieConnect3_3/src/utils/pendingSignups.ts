// ── Pending-signup self-heal queue ──────────────────────────────────────────
// When a registration is submitted while the backend is unreachable, the
// payload (including the chosen password) is parked in localStorage and
// replayed automatically by ANY open VeggieConnect tab until the server
// confirms the account. This is what makes a registration survive a server
// restart or a temporary outage: the Admin Console tab (or the registering
// tab) re-posts it as soon as the backend answers again, and the account then
// appears in the Admin Desk's "Pending User Verifications" queue as normal.
//
// NOTE: the payload intentionally includes the password so the replayed
// account can actually log in after approval. It is removed from localStorage
// the moment the server confirms the registration.

const QUEUE_KEY = 'veggieconnect_pending_signups_v1';

export interface PendingSignup {
  payload: Record<string, any>;
  queuedAt: string;
}

export function readPendingSignups(): PendingSignup[] {
  try {
    const raw = localStorage.getItem(QUEUE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    return Array.isArray(parsed) ? parsed.filter((p) => p && p.payload && p.payload.name) : [];
  } catch (e) {
    return [];
  }
}

function writeQueue(queue: PendingSignup[]): void {
  try {
    localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  } catch (e) {
    console.error('Could not save the pending signup queue', e);
  }
}

const nameKey = (n: any) => String(n || '').trim().toLowerCase();

export function queuePendingSignup(payload: Record<string, any>): void {
  const queue = readPendingSignups().filter((p) => nameKey(p.payload.name) !== nameKey(payload?.name));
  queue.push({ payload, queuedAt: new Date().toISOString() });
  writeQueue(queue);
}

export function removePendingSignup(name: string): void {
  writeQueue(readPendingSignups().filter((p) => nameKey(p.payload.name) !== nameKey(name)));
}

export function hasPendingSignupFor(name: string): boolean {
  return readPendingSignups().some((p) => nameKey(p.payload.name) === nameKey(name));
}

function announceSynced(name: string): void {
  try {
    window.dispatchEvent(new CustomEvent('veggieconnect:signup-synced', { detail: { name } }));
  } catch (e) {}
}

/**
 * Attempts ONE replay round over the queued registrations.
 * Returns the account names that are now confirmed on the server.
 */
export async function flushPendingSignups(): Promise<string[]> {
  const queue = readPendingSignups();
  const synced: string[] = [];
  for (const entry of queue) {
    const name = String(entry.payload?.name || '');
    try {
      const resp = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(entry.payload),
      });
      const data = await resp.json().catch(() => ({} as any));
      if (resp.ok) {
        synced.push(name);
        removePendingSignup(name);
        announceSynced(name);
      } else if (resp.status === 400 && /already registered|already exists/i.test(String(data?.error || ''))) {
        // The server already knows this account (e.g. the replay ran twice, or
        // another device registered it first) — treat it as delivered.
        synced.push(name);
        removePendingSignup(name);
        announceSynced(name);
      } else if (resp.status === 400 || resp.status === 422) {
        // Permanent validation rejection — this payload can never succeed, so
        // drop it instead of retrying forever.
        removePendingSignup(name);
      }
      // 5xx / other errors → keep queued; the next round will retry.
    } catch (err) {
      // Backend still unreachable — stop this round early.
      break;
    }
  }
  return synced;
}

/** Starts a lightweight retry loop (every 10s) that lives while the tab does. */
export function startPendingSignupAutoFlush(): void {
  const w = window as any;
  if (w.__vcPendingSignupFlushStarted) return;
  w.__vcPendingSignupFlushStarted = true;
  const run = () => {
    flushPendingSignups().catch(() => {});
  };
  run();
  setInterval(run, 10000);
}
